__version__ = '1.1'


def hello_world():
    print("This is my first pip package!")
