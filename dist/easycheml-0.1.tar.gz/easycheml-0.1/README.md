A simple tool for using artificial intelligence in chemistry"
